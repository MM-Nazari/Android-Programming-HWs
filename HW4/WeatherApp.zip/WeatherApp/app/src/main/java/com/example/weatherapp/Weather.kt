package com.example.weatherapp

data class Weather(
    var placename: String, var desc: String, var temp: Int, var clouds: Int
)

