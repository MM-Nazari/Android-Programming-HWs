package com.example.weatherapp.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

class Shapes {
    companion object {
        val readLocationButtons = RoundedCornerShape(8.dp)
    }
}